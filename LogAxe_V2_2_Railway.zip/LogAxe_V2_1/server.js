const express = require("express");
const session = require("express-session");
const SQLiteStore = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const crypto = require("crypto");
const fs = require("fs");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const dbPath = process.env.DB_PATH || "logaxe.sqlite";
fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
const db = new SQLiteStore(dbPath);
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === "production";
const SESSION_SECRET = process.env.SESSION_SECRET || (isProduction ? "" : "local-development-only-change-this-secret");
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || (isProduction ? "" : "admin@logaxe.local")).trim().toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || (isProduction ? "" : "ChangeMe-123!");
const SESSION_COOKIE_SECURE = process.env.COOKIE_SECURE === "true" || isProduction;
if (isProduction && (!SESSION_SECRET || SESSION_SECRET.length < 32 || !ADMIN_EMAIL || ADMIN_PASSWORD.length < 14)) {
  throw new Error("Configuration de production invalide : définissez SESSION_SECRET (32 caractères minimum), ADMIN_EMAIL et ADMIN_PASSWORD (14 caractères minimum).");
}

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 event TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS shares (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 code TEXT NOT NULL UNIQUE,
 owner_id INTEGER NOT NULL,
 active INTEGER NOT NULL DEFAULT 1,
 expires_at INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const count = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin'").get().n;
if (!count) {
 const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
 db.prepare("INSERT INTO users(name,email,password_hash,role,status) VALUES(?,?,?,?,?)")
   .run("Administrateur LogAxe", ADMIN_EMAIL, hash, "admin", "approved");
 console.log("Compte admin initialisé :", ADMIN_EMAIL);
}
app.set("trust proxy", 1);
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"30kb"}));
const SQLiteSessionStore = require("connect-sqlite3")(session);
const sessionDir = process.env.SESSION_DIR || "./data";
fs.mkdirSync(path.resolve(sessionDir), { recursive: true });
const sessionMiddleware = session({
 store: new SQLiteSessionStore({ db: "sessions.sqlite", dir: sessionDir, concurrentDB: true }),
 secret:SESSION_SECRET, resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:SESSION_COOKIE_SECURE,maxAge:8*60*60*1000}
});
app.use(sessionMiddleware);
app.use("/api",rateLimit({windowMs:15*60*1000,limit:250,standardHeaders:true,legacyHeaders:false}));
const loginLimiter = rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:true,legacyHeaders:false,message:{error:"Trop de tentatives. Réessayez dans 15 minutes."}});
app.use(express.static(path.join(__dirname,"public")));

function audit(uid,event){db.prepare("INSERT INTO audit(user_id,event) VALUES(?,?)").run(uid||null,event);}
function current(req){return req.session.user||null;}
function auth(req,res,next){if(!current(req))return res.status(401).json({error:"Connexion requise."});next();}
function admin(req,res,next){if(!current(req)||current(req).role!=="admin")return res.status(403).json({error:"Accès administrateur requis."});next();}
function safeUser(u){return {id:u.id,name:u.name,email:u.email,role:u.role,status:u.status};}

app.get("/health",(req,res)=>res.status(200).json({ok:true,service:"logaxe"}));
app.get("/api/me",(req,res)=>res.json({user:current(req)}));
app.post("/api/register",async(req,res)=>{
 const {name,email,password}=req.body||{};
 if(!name||!email||!password||String(password).length<10) return res.status(400).json({error:"Nom, e-mail et mot de passe d’au moins 10 caractères requis."});
 const normalized=String(email).trim().toLowerCase();
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized))return res.status(400).json({error:"Adresse e-mail invalide."});
 try{
  const hash=await bcrypt.hash(String(password),12);
  const info=db.prepare("INSERT INTO users(name,email,password_hash,role,status) VALUES(?,?,?,?,?)")
    .run(String(name).trim().slice(0,80),normalized,hash,"user","pending");
  audit(info.lastInsertRowid,"Demande de compte créée (en attente de validation).");
  res.status(201).json({message:"Demande reçue. Votre compte doit être validé par l’administrateur avant connexion."});
 }catch(e){res.status(409).json({error:"Cette adresse e-mail est déjà utilisée."});}
});
app.post("/api/login",loginLimiter,async(req,res)=>{
 const {email,password}=req.body||{};
 const u=db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").trim().toLowerCase());
 if(!u||!await bcrypt.compare(String(password||""),u.password_hash))return res.status(401).json({error:"Identifiants incorrects."});
 if(u.status!=="approved")return res.status(403).json({error:u.status==="pending"?"Compte en attente de validation.":"Compte suspendu."});
 req.session.regenerate((err)=>{
  if(err)return res.status(500).json({error:"Impossible d’ouvrir la session. Réessayez."});
  req.session.user=safeUser(u);
  req.session.save((saveErr)=>{
   if(saveErr)return res.status(500).json({error:"Impossible d’enregistrer la session. Réessayez."});
   audit(u.id,"Connexion.");
   res.json({user:req.session.user});
  });
 });
});
app.post("/api/logout",auth,(req,res)=>{audit(current(req).id,"Déconnexion.");req.session.destroy(()=>res.json({ok:true}));});
app.get("/api/admin/users",auth,admin,(req,res)=>{
 const rows=db.prepare("SELECT id,name,email,role,status,created_at FROM users ORDER BY created_at DESC").all();
 res.json({users:rows});
});
app.post("/api/admin/users/:id/status",auth,admin,(req,res)=>{
 const status=req.body.status;
 if(!["approved","suspended","rejected"].includes(status))return res.status(400).json({error:"Statut invalide."});
 const target=db.prepare("SELECT id,role FROM users WHERE id=?").get(req.params.id);
 if(!target)return res.status(404).json({error:"Utilisateur introuvable."});
 if(target.role==="admin")return res.status(400).json({error:"Le compte administrateur ne peut pas être modifié ici."});
 db.prepare("UPDATE users SET status=? WHERE id=?").run(status,target.id);
 audit(current(req).id,`Statut utilisateur ${target.id} modifié : ${status}.`);
 res.json({ok:true});
});
app.get("/api/admin/audit",auth,admin,(req,res)=>{
 res.json({events:db.prepare("SELECT audit.id,audit.event,audit.created_at,users.email FROM audit LEFT JOIN users ON users.id=audit.user_id ORDER BY audit.id DESC LIMIT 100").all()});
});
app.post("/api/share/create",auth,(req,res)=>{
 const code=crypto.randomBytes(18).toString("hex");
 const duration=Math.min(Math.max(Number(req.body.durationMinutes)||30,5),240);
 const expires=Date.now()+duration*60*1000;
 db.prepare("INSERT INTO shares(code,owner_id,expires_at) VALUES(?,?,?)").run(code,current(req).id,expires);
 audit(current(req).id,`Partage de position créé pour ${duration} minutes.`);
 res.json({code,expiresAt:expires});
});
app.post("/api/share/:code/stop",auth,(req,res)=>{
 const share=db.prepare("SELECT * FROM shares WHERE code=?").get(req.params.code);
 if(!share||share.owner_id!==current(req).id)return res.status(404).json({error:"Partage introuvable."});
 db.prepare("UPDATE shares SET active=0 WHERE code=?").run(req.params.code);
 io.to("share:"+req.params.code).emit("share-ended");
 audit(current(req).id,"Partage de position arrêté.");
 res.json({ok:true});
});
app.get("/api/share/:code/info",(req,res)=>{
 const s=db.prepare("SELECT code,active,expires_at FROM shares WHERE code=?").get(req.params.code);
 if(!s||!s.active||s.expires_at<Date.now())return res.status(404).json({error:"Lien expiré ou désactivé."});
 res.json({active:true,expiresAt:s.expires_at});
});

// Share the same persistent Express session with Socket.IO handshakes.
io.engine.use(sessionMiddleware);

io.on("connection",(socket)=>{
 socket.on("join-share",(payload={})=>{
  const {code,mode}=payload||{};
  const u=socket.request.session?.user;
  const share=db.prepare("SELECT * FROM shares WHERE code=?").get(String(code||""));
  if(!share||!share.active||share.expires_at<Date.now()){socket.emit("share-error","Lien invalide, expiré ou désactivé.");return;}
  if(mode==="owner" && (!u||u.id!==share.owner_id)){socket.emit("share-error","Seul le propriétaire connecté peut partager sa position.");return;}
  if(mode==="viewer" && u?.id===share.owner_id){socket.emit("share-error","Ouvrez le lien depuis l’appareil qui consulte la position.");return;}
  socket.join("share:"+code);
  socket.data.shareCode=code;socket.data.mode=mode;
  socket.emit("share-joined",{mode});
 });
 socket.on("location-update",(payload={})=>{
  const {lat,lon,accuracy}=payload||{};
  const code=socket.data.shareCode;
  if(!code||socket.data.mode!=="owner")return;
  const share=db.prepare("SELECT active,expires_at FROM shares WHERE code=?").get(code);
  if(!share||!share.active||share.expires_at<Date.now()){socket.emit("share-ended");return;}
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
  socket.to("share:"+code).emit("location-update",{lat,lon,accuracy:Number(accuracy)||null,updatedAt:Date.now()});
 });
 socket.on("disconnect",()=>{});
});

app.get("/share/:code",(req,res)=>res.sendFile(path.join(__dirname,"public","share.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
server.listen(PORT, "0.0.0.0", ()=>console.log(`LogAxe V2 disponible sur le port ${PORT}`));
