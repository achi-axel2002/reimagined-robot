# LogAxe V2.2 — Accès mixte, durcissement initial

## Ce qui est inclus
- Inscription publique avec statut `pending`.
- Connexion réservée aux comptes approuvés.
- Compte administrateur initialisé au premier démarrage.
- Tableau de bord administrateur : approuver, rejeter ou suspendre les comptes.
- Journal d'activité.
- Partage temporaire de position en direct par Socket.IO.
- Lien de partage avec code aléatoire, durée limitée et arrêt manuel.
- Analyse heuristique locale des numéros, liens et messages suspects.

## Prérequis
- Node.js 20 ou supérieur
- npm

## Installation
1. Décompresser l'archive.
2. Dans le dossier `LogAxe_V2_1`, copier `.env.example` vers `.env` et modifier les secrets.
3. Installer les dépendances : `npm install`
4. Lancer : `npm start`
5. Ouvrir `http://localhost:3000`

Compte administrateur de développement local uniquement (ne pas utiliser en production) :
- E-mail : `admin@logaxe.local`
- Mot de passe : `ChangeMe-123!`

## Configuration recommandée
Définir les variables d'environnement :
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `SESSION_SECRET` (secret aléatoire long)
- `PORT` (facultatif)
- `DB_PATH` (facultatif)
- `COOKIE_SECURE=true` en HTTPS

## Déploiement
La géolocalisation du navigateur exige HTTPS en production (localhost est accepté pour les tests). Déployer derrière un reverse proxy HTTPS, activer `COOKIE_SECURE=true`, utiliser un secret de session fort, sauvegarder la base SQLite et limiter l'accès administrateur. Pour une production multi-instance, remplacer les sessions mémoire par un store persistant et utiliser PostgreSQL/Redis.

## Consentement et confidentialité
Le propriétaire doit être connecté, cliquer pour créer un partage, accepter la permission GPS du navigateur et peut arrêter le partage. Le code de partage est temporaire et doit être transmis uniquement à la personne choisie. Le navigateur doit rester ouvert pour l'envoi continu de position. La personne qui consulte le lien peut voir la position pendant la durée autorisée. Ne pas utiliser pour surveiller quelqu'un sans son accord.

## Limites de cette V2
- Le lien de partage est un jeton porteur : toute personne qui le reçoit peut voir la position pendant sa validité. Transmettez-le de manière privée.
- Pas encore de vérification d'e-mail, récupération de mot de passe, authentification à deux facteurs, modération de signalements, intégration à des bases externes de fraude ou notifications push.
- La détection d'arnaques est heuristique et ne certifie ni la fiabilité ni la fraude.
- Pour un lancement public, faire auditer la sécurité, ajouter une politique de confidentialité et des conditions d'utilisation, définir les durées de conservation et se conformer aux lois applicables en matière de données personnelles.


## Déploiement Railway (configuration recommandée)
1. Créez un projet Railway et importez ce dossier depuis un dépôt GitHub privé.
2. Dans le service Node.js, ajoutez un Volume monté sur `/data`.
3. Définissez les variables :
   - `ADMIN_EMAIL` : votre adresse d'administration
   - `ADMIN_PASSWORD` : un mot de passe long et unique
   - `SESSION_SECRET` : une chaîne aléatoire longue (au moins 32 caractères)
   - `DB_PATH=/data/logaxe.sqlite`
   - `SESSION_DIR=/data`
   - `COOKIE_SECURE=true`
4. Vérifiez que la commande de démarrage est `npm start`.
5. Après le déploiement, vérifiez `https://VOTRE-DOMAINE/health` : le résultat attendu est `{"ok":true,"service":"logaxe"}`.
6. Dans Settings → Networking, générez d'abord un domaine Railway provisoire. Testez inscription, validation admin, connexion et partage GPS sur HTTPS.
7. Ajoutez ensuite `logaxe.com` dans Custom Domain et configurez exactement les enregistrements DNS CNAME et TXT affichés par Railway.
8. Activez la redirection du domaine racine vers `www` (ou inversement) après avoir ajouté les deux noms au service.

Le Volume `/data` conserve la base SQLite et les sessions lors des redémarrages. Gardez une seule instance applicative tant que la base SQLite est utilisée. Pour une charge importante ou plusieurs instances, migrez vers PostgreSQL et un store de sessions partagé.

## Avant ouverture au public
La V2.2 ajoute notamment une régénération de session à la connexion, une limite dédiée aux tentatives de connexion et le refus de démarrer en production si les secrets et identifiants administrateur requis ne sont pas configurés. La persistance des sessions et le partage de session Socket.IO sont conservés. Cela ne remplace pas un audit de sécurité. Faire vérifier la gestion des liens de partage, ajouter vérification d'e-mail, récupération de mot de passe, MFA, protections anti-abus, sauvegardes testées, politique de confidentialité et mécanisme de suppression des données avant de traiter de vraies données sensibles.
